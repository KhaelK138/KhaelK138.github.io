#ifndef _CONFIG_H
#define _CONFIG_H

#define HOMEDIR		"/root"
#define GET_FILE 	1
#define PUT_FILE 	2
#define RUNSHELL 	3
#define SET_DELAY 	4
#define OUT 		5
#define EXIT_LEN 	16
#define EXIT 		";7(Zu9YTsA7qQ#vw"

#endif