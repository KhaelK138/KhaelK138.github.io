
#!/usr/bin/env python3
import sys

def parse_ip_range(ip_range):
    parts = ip_range.split('.')
    if len(parts) != 4:
        raise SystemExit("Invalid IP range format")

    def expand(part):
        vals = []
        for section in part.split(','):
            if '-' in section:
                s, e = map(int, section.split('-'))
                vals.extend(range(s, e + 1))
            else:
                vals.append(int(section))
        return vals

    expanded = [expand(p) for p in parts]
    return [f"{a}.{b}.{c}.{d}" for a in expanded[0] for b in expanded[1] for c in expanded[2] for d in expanded[3]]

def main():
    if len(sys.argv) != 2:
        print(f"Usage: {sys.argv[0]} <ip_range>")
        sys.exit(1)

    ip_range = sys.argv[1]
    ips = parse_ip_range(ip_range)
    print(f"Input: {ip_range}")
    print(f"Generated {len(ips)} IPs:\n")
    for ip in ips:
        print(ip)

if __name__ == "__main__":
    main()

