#ifndef BECOME_ROOT_H
#define BECOME_ROOT_H
int become_root_init(void);
void become_root_exit(void);
#endif
