#ifndef HOOKS_TASKSTATS_H
#define HOOKS_TASKSTATS_H

int taskstats_hook_init(void);
void taskstats_hook_exit(void);

#endif