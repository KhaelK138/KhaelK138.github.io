#ifndef HIDING_ICMP_H
#define HIDING_ICMP_H

int hiding_icmp_init(void);
void hiding_icmp_exit(void);

#endif