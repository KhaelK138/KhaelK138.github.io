#ifndef RESET_TAINTED_H
#define RESET_TAINTED_H
int reset_tainted_init(void);
void reset_tainted_exit(void);
#endif
