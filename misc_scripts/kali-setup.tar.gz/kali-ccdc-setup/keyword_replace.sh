#!/usr/bin/env bash

if [ "$#" -ne 2 ]; then
    echo "Usage: $0 <old_string> <new_string>"
    exit 1
fi

OLD="$1"
NEW="$2"

# GNU sed version (Fedora/Linux)
grep -rl -- "$OLD" . | while read -r file; do
    sed -i "s/${OLD}/${NEW}/g" "$file"
done

