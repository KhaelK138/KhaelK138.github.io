import argparse
import socket

def main():
    parser = argparse.ArgumentParser(description="Broadcast command to all watershell listeners")
    parser.add_argument("command", help="Command to run (without run: prefix)")
    parser.add_argument("-p", "--port", type=int, required=True, help="Watershell UDP port")

    args = parser.parse_args()

    payload = f"run:{args.command}".encode()

    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)

    sock.sendto(payload, ("255.255.255.255", args.port))
    sock.close()

if __name__ == "__main__":
    main()

