#ifndef BPF_HOOK_H
#define BPF_HOOK_H

notrace int bpf_hook_init(void);
notrace void bpf_hook_exit(void);

#endif
