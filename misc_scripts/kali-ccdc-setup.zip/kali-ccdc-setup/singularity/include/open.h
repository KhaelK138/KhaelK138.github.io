#ifndef HIDING_OPEN_H
#define HIDING_OPEN_H

int hiding_open_init(void);
void hiding_open_exit(void);

#endif
