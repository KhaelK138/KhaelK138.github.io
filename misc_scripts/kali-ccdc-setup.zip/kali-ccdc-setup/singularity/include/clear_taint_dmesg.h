#ifndef CLEAR_TAINT_DMESG_H
#define CLEAR_TAINT_DMESG_H
int clear_taint_dmesg_init(void);
void clear_taint_dmesg_exit(void);
#endif
