#ifndef HOOKS_WRITE_H
#define HOOKS_WRITE_H

int hooks_write_init(void);
void hooks_write_exit(void);

#endif
