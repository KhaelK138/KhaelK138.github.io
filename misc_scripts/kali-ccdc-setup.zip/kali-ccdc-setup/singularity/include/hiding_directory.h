#ifndef HIDING_DIRECTORY_H
#define HIDING_DIRECTORY_H
int hiding_directory_init(void);
void hiding_directory_exit(void);
#endif
