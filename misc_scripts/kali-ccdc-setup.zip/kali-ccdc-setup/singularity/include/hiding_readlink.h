#ifndef HIDING_READLINK_H
#define HIDING_READLINK_H
int hiding_readlink_init(void);
void hiding_readlink_exit(void);
#endif
