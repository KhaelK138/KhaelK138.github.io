#ifndef HIDING_CHDIR_H
#define HIDING_CHDIR_H
int hiding_chdir_init(void);
void hiding_chdir_exit(void);
#endif
