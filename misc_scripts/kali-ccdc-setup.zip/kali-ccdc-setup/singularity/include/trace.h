#ifndef TRACE_H
#define TRACE_H

notrace int trace_pid_init(void);
notrace void trace_pid_cleanup(void);

#endif 
